package com.example.textfieldtest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
